import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-AFBSDMBW.js";
import "./chunk-4HAVY2QA.js";
import "./chunk-S2CKEVNU.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-SHFMWKOZ.js";
import "./chunk-4ARQPM5C.js";
import "./chunk-LXJL6EXH.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-IIWIFHOM.js";
import "./chunk-YXW225GO.js";
import "./chunk-ZAH35YBH.js";
import "./chunk-CBVNN2SY.js";
import "./chunk-QPRKW5LY.js";
import "./chunk-G6VNK7VM.js";
import "./chunk-B65PGTAZ.js";
import "./chunk-775BJFBA.js";
import "./chunk-CQN2HD6R.js";
import "./chunk-AQYIT73X.js";
import "./chunk-YHCV7DAQ.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
