import {
  MatDivider,
  MatDividerModule
} from "./chunk-B5QFNO53.js";
import "./chunk-V4SXFFAT.js";
import "./chunk-UBGM4B6N.js";
import "./chunk-6Y7T4UFD.js";
import "./chunk-MYNZLU7S.js";
import "./chunk-FEVA2NVZ.js";
import "./chunk-LL5RF35Z.js";
import "./chunk-733PALXA.js";
import "./chunk-S35MAB2V.js";
export {
  MatDivider,
  MatDividerModule
};
