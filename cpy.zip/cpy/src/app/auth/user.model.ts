export interface User {
    email: string;
    pass: string;
  }