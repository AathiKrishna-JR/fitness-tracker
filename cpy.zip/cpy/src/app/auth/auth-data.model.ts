export interface AuthData {
    email: string;
    passwordHash: string;
    birthdate: string;
    CreatedOn: string;
  }